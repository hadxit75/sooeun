import axios from 'axios';
import store from '@/store';

// Backend와 통신할 때 공통적으로 사용되는 내용 입니다.
// baseUri: 서버 IP
// apiList: 통신할 API 주소 목록
export const info = {
  baseUri: '//183.111.125.212:8080/',
  apiList: {
    deleteServer: 'api/server/',
    getServer: 'api/servers',
    getReport: 'api/reports',
    login: 'api/auth/login',
    refreshToken: 'api/auth/token',
    addServer: 'api/server/create',
  },
};

/**
 * 백엔드와 기본적인 통신 시 사용하는 함수
 * 헤더에 accessToken을 같이 전달한다.
 * @return {object} backEnd와 통신할 수 있는 Axios 객체
 */
export function Api() {
  const apiCreate = axios.create({
    baseURL: info.baseUri,
    headers: {
      Authorization: `Bearer ${store.getters.accessToken}`
    },
  });
  return apiCreate;
};

/**
 * 토큰 리프레시 시 사용하는 함수
 * 헤더에 refreshToken을 같이 전달한다.
 * @return {object} backEnd와 통신할 수 있는 Axios 객체
 */
export function RefreshApi() {
  const apiCreate = axios.create({
    baseURL: info.baseUri,
    headers: {
      Authorization: `Bearer ${store.getters.refreshToken}`
    },
  });
  return apiCreate;
};

/**
 * 백엔드와 통신하여 로그인하는 함수
 * @return {object} backend와 통신하여 로그인 할 수 있는 Axios 객체
 */
export function LoginApi() {
  const apiCreate = axios.create({
    baseURL: info.baseUri,
    headers: {
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  return apiCreate;
};

/**
 * 백엔드와 통신하여 내용을 수정하는 함수
 * @return {object} backend와 통신하여 내용을 수정하는  Axios 객체
 */
export function PutApi() {
  const apiCreate = axios.create({
    baseURL: info.baseUri,
    headers: {
      Authorization: `Bearer ${store.getters.refreshToken}`,
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  return apiCreate;
}