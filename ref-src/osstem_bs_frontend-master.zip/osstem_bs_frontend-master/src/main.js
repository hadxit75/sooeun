// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import Vuetify from 'vuetify'
import './stylus/main.styl'
import App from './App'
import { router } from './router'
import VeeValidate from 'vee-validate';
import store from './store'
import 'golden-layout/src/css/goldenlayout-light-theme.css'
import VueGoldenLayout from 'vue-golden-layout'

Vue.config.productionTip = false

// 플러그인 로드
Vue.use(Vuetify)
Vue.use(VeeValidate, { errorBagName: "errors", locale: 'en' })
Vue.use(VueGoldenLayout);

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App },
  render: h => h(App)
}).$mount('#app')
