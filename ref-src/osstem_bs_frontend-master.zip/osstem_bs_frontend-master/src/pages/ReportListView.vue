<template>
  <div>
    <div class="tableTitle">
        <h2>전체 보고서 목록</h2>
        <span>총 8건</span>
        <select name="" id="selectOption">
        	<option value="최신순">최신순</option>
        	<option value="인기순">인기순</option>
        </select>
    </div>
    <report-table type="table" hideToolbar :headers="headers">
      <template slot-scope="data">
          <tr @click="clickReportList(data.item)">
            <td class="td1">{{ data.item.reportId }}</td>
            <td class="td2">{{ data.item.reportName }}</td>
            <td class="td3">{{ data.item.reportDescript }}</td>
            <td class="td4">이수연</td>
          </tr>
      </template>
    </report-table>
  </div>
</template>

<script>
import ReportTable from '@/components/reportList/ReportTable.vue';
import ReportView from '@/pages/ReportView.vue'

export default {
  data() {
    return {
      /*headers: [
        { text: 'Report Id', value: 'reportId' },
        { text: 'Report Name', value: 'reportName' },
        { text: 'Report Descript', value: 'reportDescript' },
        { text: '', value: 'name', sortable: false }
        
      ]*/
      headers: [
        { text: '선택', value: 'reportId' },
        { text: '번호', value: 'reportName' },
        { text: '제목', value: 'reportDescript' },
        { text: '작성자', value: 'name', sortable: false }
        
      ]
    };
  },
  components: {
    ReportTable
  },
  methods: {
    clickReportList(report) {
      this.$store.commit('REPORT_OBJECT', [report]);
      this.$router.push('/viewer');
    }
  },
};
</script>

<style scoped>
td {
  cursor: pointer;
}

main #listContainer .tableTitle {
	width: 100%;
	height: 40px;
	border-bottom: 1px solid #dcdcdc;
}

main #listContainer .tableTitle h2 {
	display: inline-block;
	font-size: 20pt;
	color: #444444;
}

main #listContainer .tableTitle span {
	display: inline-block;
	font-size: 10pt;
	margin-left: 14px;
	color: #444444;
}

main #listContainer .tableTitle #selectOption {
	width: 153px;
	height: 35px;
	float: right;
	border: 1px solid #c8c8c8;
	box-sizing: border-box;
}

/*main #listContainer table {
	margin-top: 24px;
	display: block;
	width: 100%;
}

main #listContainer table thead {
	border-top: 2px solid #797979;
	display: block;
	width: 100%;
	height: 40px;
}

main #listContainer table thead tr {
	background: #f8f8f8;
	display: block;
	width: 100%;
	height: 100%;
}

main #listContainer table thead tr th {
	display: inline-block;
	border-right: 1px solid #dadada;
	height: 100%;
	line-height: 40px;
	font-size: 11pt;
	font-weight: normal;
    border-bottom: 1px solid #dadada;
}

main #listContainer table thead tr td {
	display: inline-block;
	height: 100%;
	line-height: 40px;
	font-size: 11pt;
	font-weight: normal;
}

main #listContainer table tbody {
	display: block;
	width: 100%;
    text-align: center;
}

main #listContainer table tbody tr {
	background: #fff;
	display: block;
	width: 100%;
	height: 100%;
    border-bottom: 1px solid #dadada;
}

main #listContainer table tbody tr th {
	display: inline-block;
	height: 100%;
	line-height: 40px;
	font-size: 11pt;
	font-weight: normal;
    border-right: 1px solid #dadada;
}

main #listContainer table tbody tr td {
	display: inline-block;
	height: 100%;
	line-height: 40px;
	font-size: 11pt;
	font-weight: normal;
    border-right: 1px solid #dadada;
}

main #listContainer table thead tr .td1 {
	width: 112px;
}

main #listContainer table thead tr .td2 {
	width: 120px;
}

main #listContainer table thead tr .td3 {
	width: 726px;
}

main #listContainer table thead tr .td4 {
	width: 186px;
	border-right: none;
}

main #listContainer table tbody tr .td1 {
	width: 112px;
}

main #listContainer table tbody tr .td2 {
	width: 120px;
}

main #listContainer table tbody tr .td3 {
	width: 726px;
}

main #listContainer table tbody tr .td4 {
	width: 186px;
	border-right: none;
}*/
</style>
