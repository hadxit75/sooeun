<template>
  <div id="wrap">
    <h2 class="mb-5">서버 목록</h2>
    <server-table type="table" hideToolbar :headers="headers" >
      <template slot-scope="data">
        <tr>
          <td>{{ data.item.server_id }}</td>
          <td>{{ data.item.server_name }}</td>
          <td>{{ data.item.server_descript }}</td>
          <td>{{ data.item.server_ip }}</td>
          <v-btn icon class="mx-0" @click="server_Delete(data.item.server_id)">
            <v-icon color="grey">delete</v-icon>
          </v-btn>
        </tr>
      </template>
    </server-table>
    <form @submit.prevent="addServer">
      <h2>서버 추가</h2>
      <div>
        <label for="server-name">서버 이름: </label>
        <input type="text" name="server-name" v-model="serverName">
      </div>
      <div>
        <label for="server-descript">서버 설명: </label>
        <input type="text" name="server-descript" v-model="serverDescript">
      </div>
      <div>
        <label for="server-address">서버 주소: </label>
        <input type="text" name="server-address" v-model="serverAddress">
      </div>
      <button>추가</button>
    </form>
  </div>
</template>

<script>
import ServerTable from '@/components/serverList/ServerTable.vue';
import {Api, PutApi, info} from '@/api/backend.js';

export default {
  data() {
    return {
      headers: [
        { text: 'Server Id', value: 'server_id' },
        { text: 'Server Name', value: 'server_name' },
        { text: 'Server Descript', value: 'server_descript' },
        { text: 'Server IP', value: 'server_ip' },
        { text: '', value: 'name', sortable: false }
      ],
      // 서버 추가 입력 받는 곳
      serverName: '',
      serverDescript: '',
      serverAddress: '',

    };
  },
  components: {
    ServerTable
  },
  methods: {
    async addServer() {
      const json =
        `{"server_id": "", 
        "server_name": "${this.serverName}", 
        "server_descript": "${this.serverDescript}", 
        "server_ip": "${this.serverAddress}", 
        "server_url": "http://${this.serverAddress}"}`;
      // axios를 통해 서버와 통신
      try{
        const addResult = (await PutApi().put(info.apiList.addServer, json)).data;
        alert('등록 성공');
        window.location.reload()
      } catch (error){
        alert('등록에 실패하였습니다.');
        console.log(error);
      }
    },
    async server_Delete(delData) {
      try {
        await Api().delete(info.apiList.deleteServer+delData);
        window.location.reload()
      } catch (error) {
        alert('삭제에 실패하였습니다.');
        console.log(error);
      }
    }
  },
};
</script>

<style scoped>
form {
  margin: 20px;
  border: 1px solid black;
}
input {
  background: white;
}
form button {
  background: gray;
}
</style>
