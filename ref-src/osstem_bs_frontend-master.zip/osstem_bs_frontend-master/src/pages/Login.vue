<template>
    <login-card></login-card>
</template>

<script>
import LoginCard from "../components/login/LoginCard.vue";
import tokenManager from "@/util/token-manager.js";

export default {
  name: "register",
  // 이 페이지에서는 다음과 같은 컴포넌트를 사용함
  // Login
  components: {
    LoginCard
  },
};
</script>

<style>
@import url('https://cdn.rawgit.com/moonspam/NanumSquare/master/nanumsquare.css');
</style>