<template>
  <div class="text-md-center pa-4 mt-4">
    <h1 class="display-2 primary--text">Whoops, 500</h1>
    <p>Sorry something went wrong.</p>
    <div><v-btn outline color="primary" :to="{path: `/`}">Get me out of here!</v-btn></div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'


export default {
  name: 'P404',
}
</script>
