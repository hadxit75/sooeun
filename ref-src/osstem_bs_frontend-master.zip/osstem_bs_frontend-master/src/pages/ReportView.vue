<template>
  <div id="reportViewWrap">
    <div class="buttonHeader">
      <button @click="newTestTab" class="newTab">새 탭</button>
      <div class="parameterSettingBtnWrap">
        <button v-on:click="isShow=!isShow" class="parameterSettingBtn">파라미터 설정</button>
      </div>
      <div class="parameterSettingChangeTable" v-if="!isShow">
      <table>
        <thead>
          <tr>
            <th>항목</th>
            <th>내용</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>설정변경</th>
            <td>
              <select class="parameterSelect">
                <option value="년도">년도</option>
              </select>
              <select class="parameterSelect">
                <option value="경영정보방침">경영정보방침</option>
              </select>
            </td>
          </tr>
        </tbody>
        <button class="applyBtn">적용하기</button>
      </table>
    </div>
      <div class="reportSettingBtnWrap">
        <button class="reportSettingBtn" v-on:click="isHidden=!isHidden">보고서 설정변경</button>
      </div>
      <div class="reportSettingChangeTable" v-if="!isHidden">
      <table>
        <thead>
          <tr>
            <th>항목</th>
            <th>내용</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>갱신주기</th>
            <td></td>
          </tr>
          <tr>
            <th>보고서 모니터 지정</th>
            <td></td>
          </tr>
          <tr>
            <th>탭 플레이 주기</th>
            <td></td>
          </tr>
        </tbody>
        <button class="applyBtn">적용하기</button>
      </table>
    </div>
    </div>
    <golden-layout v-model="windowState" class="hscreen">
      <!-- 페이지 컴포넌트를 실제 띄우는 위치 -->
        <gl-stack>
          <gl-component
          v-for="tab in tabStack"
          :key="tab.reportId"
          :title="tab.reportName"
          @destroy="tabClosed(tab)"
          :state="{tab}"
          template="report"
          />
        </gl-stack>
      <!-- 페이지 컴포넌트 -->
      <template v-slot:report="{tab}">
        <a-report :reportInfo="tab"></a-report>
      </template>
    </golden-layout>
  </div>
</template>

<script>
import AReport from "@/components/reportView/AReport.vue";

export default {
  components:{
    AReport,
  },
  data() {
    return {
      // 전체 창 상태 저장
      windowState: null,
      // Tab별 reportObject(정보) 저장
      tabStack: [],
      isShow: true,
      isHidden: true
    };
  },
  created() {
    const reportArray = this.$store.getters.reportObject;
    if(reportArray.length !== 0) {
      reportArray.forEach(reportObject => {
        this.newTab(reportObject);
      });
      this.$store.commit('REPORT_OBJECT', []);
    }
  },
  methods: {
    log() {
      console.log(this.windowState);
    },
    newTab(reportObject){
      console.log(reportObject);
      const newObject = Object.assign({}, reportObject);
      this.tabStack.push(newObject);
    },
    tabClosed(tabInfo) {
      let tabInfoIndex = this.tabStack.indexOf(tabInfo);
      this.tabStack.splice(tabInfoIndex, 1);
    },
    newTestTab() {
      const test = {
        reportId: Math.random() * 100 + 1,
        reportName: '탭 테스트 보고서',
        reportUrl: 'http://183.111.125.212:18080/#/chartTest/',
      };
      this.newTab(test);
    },
    parameterBtn: function (event) {
      // 자식요소 div를 클릭하면 보여준다.
    }
  },
};
</script>


<style>
#reportViewWrap {
  position: relative;
}

.buttonHeader {
  width: 100%;
  height: 50px;
  position: relative;
}

button {
  position: absolute;
  width: 100px;
  height: 30px;
  border: 1px solid #000;
  border-radius: 5px;
  font-size: 9pt;
  line-height: 30px;
  top: 0;
}

#reportViewWrap button.newTab {
  left: 0px;
}

#reportViewWrap .reportSettingBtnWrap {
  right: 0;
  top: 0;
  position: absolute;
}

#reportViewWrap .parameterSettingBtnWrap {
  position: absolute;
  right: 160px;
  top: 0;
}

#reportViewWrap .parameterSettingBtnWrap button.parameterSettingBtn {
  position: relative;
}

#reportViewWrap .reportSettingBtnWrap button.reportSettingBtn {
  position: relative;
}

#reportViewWrap .reportSettingChangeTable, #reportViewWrap .parameterSettingChangeTable {
  position: absolute;
  right: 0;
  top: 32px;
  z-index: 2;
  width: 500px;
  height: 350px;
  background-color: rgba(0, 0, 0, 0.6);
}

#reportViewWrap .reportSettingChangeTable table, 
#reportViewWrap .parameterSettingChangeTable table {
  width: 400px;
  height: 200px;
  margin: 0 auto;
  border: 1px solid #797979;
  margin-top: 50px;
  position: relative;
  box-sizing: border-box;
}

#reportViewWrap .reportSettingChangeTable table thead tr th, 
#reportViewWrap .parameterSettingChangeTable table tr th {
  color: #000;
  background: #ddd;
  border: 1px solid #797979;
  font-size: 10pt;
  height: 40px;
}

#reportViewWrap .reportSettingChangeTable table thead tr th:nth-of-type(1), 
#reportViewWrap .parameterSettingChangeTable table th:nth-of-type(1) {
  width: 150px;
}

#reportViewWrap .reportSettingChangeTable table tbody tr th, 
#reportViewWrap .parameterSettingChangeTable table tbody tr th {
  width: 150px;
  color: #000;
  background: #ddd;
  border: 1px solid #797979;
  font-size: 9pt;
}

#reportViewWrap .reportSettingChangeTable table tr td, 
#reportViewWrap .parameterSettingChangeTable table tr td {
  background: #fff;
  border: 1px solid #797979;
  font-size: 9pt;
  padding: 5px;
}

#reportViewWrap .reportSettingChangeTable table .applyBtn, 
#reportViewWrap .parameterSettingChangeTable table .applyBtn {
  background: #cc6633;
  color: #fff;
  font-weight: bold;
  border: none;
  position: absolute;
  top: 240px;
  left: 50%;
  margin-left: -50px;
}

select {
    -webkit-appearance: none;
       -moz-appearance: none;
            appearance: none;
}

.parameterSelect {
  width: 80px;
  height: 20px;
  border: 1px solid #000;
  text-align: center;
}

.hscreen {
  width: 100%;
  height: 70vh;
  overflow: hidden;
}

.areport {
  width: 100%;
  height: 100vh;
  overflow-y: hidden;
}

.lm_header {
  background: #fafafa;
  height: 40px !important;
}

.lm_header .lm_tab {
  background: #ff6600;
  color: #fff;
  height: 85%;
}

.lm_title {
  font-size: 10pt;
  font-weight: bold;
  margin-left: 10px;
  line-height: 3;
}

.lm_tabs {
  height: 100%;
}

.lm_tab {
  width: 100px;
  padding: 20px;
  background: #b3d4fc;
  border-top-left-radius: 0.5em;
  border-top-right-radius: 0.5em;
  height: 100%;;
}

.lm_items {
  background: #fafafa;
}

.gContent {
  background: #b3d4fc;
}

.lm_content {
  border: none;
}

/* iframe */
iframe {
  border: none;
}

button:focus { 
	outline:none 
}
</style>
