<template>
  <div id="wrap">
    <h1>보고서 목록</h1>
    <h4>Tab 메뉴 보고서 목록</h4>
    <p>Hello Talentera</p>
    <chart url="http://www.mocky.io/v2/5acbd2572f00005300411775"></chart>
  </div>
</template>

<script>
import ChartsBuilder from "@/components/chartsBuilder/ChartsBuilder.vue";
import { Api } from "@/api/mockey.js";

export default {
  name: "Charts",
  data() {
    return {
      charts: []
    };
  },
  components: {
    chart: ChartsBuilder
  }
};
</script>

<style>
</style>

