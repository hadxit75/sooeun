// Vue-Router을 사용하기 위해 필요한 라이브러리들 import
import Vue from 'vue';
import VueRouter from 'vue-router';
// Vuex를 사용하기 위해 store import
import store from '@/store/index.js';
import tokenManager from '@/util/token-manager.js';

// VueRouter 등록
Vue.use(VueRouter);

// 이동 가능한 페이지 목록을 불러옴
import routes from './routes.js';

// VueRouter 객체
export const router = new VueRouter({
  routes: routes,
  base: process.env.ROUTER_BASE,
  mode: 'history'
});

// 라우터 네비게이션 가드(개발: 허현범)
/*
  to : 이동할 url
  from : 현재 url
  next : to에서 지정한 url로 이동하기 위해 호출해야 하는 함수
 */
router.beforeEach((to, from, next) => {
  if (store.getters.refreshToken === '') {
    // Vuex에 토큰이 없으면, 쿠키에서 Vuex로 토큰 가져옴.
    tokenManager.loadTokenFromCookie();
  } else if (store.getters.accessToken === '') {
    // RefreshToken만 Vuex에 있다면, 토큰 갱신 시도
    tokenManager.refreshToken()
      .then(() => {
        // 갱신 성공 시, 페이지 이동
        next();
      }).catch((error) => {
        // 갱신 실패 시, 오류 출력 후 로그인 페이지로.
        console.log(error);
        alert('토큰 갱신에 실패했습니다,\n'
          + '다시 로그인을 해 주세요.');
        next('/login');
      });
  }
  // 현자 사용자의 권한을 저장
  // 0-비로그인 1-사용자 2-관리자
  let userPerm = 0;
  // AccessToken이 Vuex에 있다면, 일반 사용자 이상
  if(store.getters.accessToken !== '') {
    userPerm++;
  }
  // 현재 사용자가 관리자인지 확인
  if (userPerm == 1
        && store.getters.accessTokenData.scopes.some((scope) => {
          return scope === 'ADMIN';          
        })) {
    userPerm++;
  }
  // 페이지 정보 확인 후 처리
  const pagePermission = to.meta.permission;
  if(pagePermission === undefined){
    // 일반 사용자용 페이지
    if(userPerm > 1){
      next();
    }
    else{
      alert('로그인 시간이 만료되었거나,\n'
       + '로그인을 하지 않은 상태입니다.\n'
       + '로그인을 해 주세요.');
       next('/login');
    };
  } else if(pagePermission === 'PUBLIC') {
    next();
  } else if(pagePermission === 'ADMIN') {
    if(userPerm == 2){
      next();
    } else {
      alert('관리자만 접근 가능합니다.');
      next('/`${store.getters.firstPagePath}');
    }
  }

  // if (store.getters.accessToken !== '') {
  //   // AccessToken가 Vuex에 있다면, 페이지 이동
  //   next();
  // } else if (store.getters.refreshToken !== '') {
  //   // RefreshToken만 Vuex에 있다면, 토큰 갱신 시도
  //   tokenManager.refreshToken()
  //     .then(() => {
  //       // 갱신 성공 시, 페이지 이동
  //       next();
  //     }).catch((error) => {
  //       // 갱신 실패 시, 오류 출력 후 로그인 페이지로.
  //       console.log(error);
  //       alert('토큰 갱신에 실패했습니다,\n'
  //         + '다시 로그인을 해 주세요.');
  //       next('/login');
  //     });
  // } else if (to.matched.some((routeInfo) => {
  //   return routeInfo.meta.publicPage;
  // })) {
  //   // 접근하는 페이지가 public 페이지라면, 페이지 이동
  //   next();
  // } else {
  //   // 어떤 경우에도 해당되지 않는다면?
  //   // 경고 출력 후 로그인 페이지로 이동.
  //   alert('로그인 시간이 만료되었거나,\n'
  //     + '로그인을 하지 않은 상태입니다.\n'
  //     + '로그인을 해 주세요.');
  //   next('/login');
  // }
});
