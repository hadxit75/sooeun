import store from '@/store/index.js'

// Load Components
import ReportView from '@/pages/ReportView.vue';
import Charts from '@/pages/Charts';
import ReportListView from '@/pages/ReportListView.vue';
import ServerListView from '@/pages/ServerListView.vue';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import Form from '@/pages/Form';
import Page404 from '@/pages/Page404';
import Page500 from '@/pages/Page500';

/* FUNCTIONS */

/**
 * 로그인 여부에 따라 페이지를 이동합니다.
 * 로그인 상태일 경우 Vuex에 설정된 메인으로 이동합니다.
 * 로그인 상태가 아닐 시 로그인 페이지로 이동합니다.
 */
const skipLogin = (to, from, next) => {
  if (store.getters.accessToken !== '') {
    next(store.getters.firstPagePath);
  } else {
    next();
  }
};

/* PAGES(VIEWS) */

export default [
  /*
  메인 페이지,
  로그인 상태에 따라 자동 redirect
  비로그인시 login
  로그인시 vuex에 저장된 위치
  */
  {
    path: '/',
    beforeEnter: skipLogin,
    redirect: '/login',
    meta: {
      permission: 'PUBLIC',
    }
  },
  /*
  로그인페이지,
  로그인 필요 없음(Public Page)
  SimpleLayout 적용
  */
  {
    path: '/login',
    component: Login,
    beforeEnter: skipLogin,
    meta: {
    permission: 'PUBLIC',
    layout: 'simple-layout'
    }
  },
  {
    path: '/viewer',
    name: 'report-view',
    component: ReportView,
    meta: {
      layout: 'app-layout'
    }
  },
  {
    path: '/charts',
    name: 'charts',
    component: Charts,
    meta: {
      layout: 'app-layout'
    }
  },
  {
    path: '/report-list',
    name: 'ReportList',
    component: ReportListView,
    meta: {
      layout: 'app-layout'
    },
  },
  {
    path: '/server-list',
    name: 'ServerList',
    component: ServerListView,
    meta: {
      layout: 'app-layout'
    },
  },
  {
    path: '/register',
    name: 'register',
    component: Register,
    meta: {
      layout: 'simple-layout'
    }
  },
  {
    path: '/form',
    name: 'form',
    component: Form,
    meta: {
      layout: 'app-layout'
    }
  },
  {
    path: '/server-error',
    name: 'page500',
    component: Page500,
    meta: {
      layout: 'simple-layout'
    }
  },
  {
    path: '/*',
    name: 'page404',
    component: Page404,
    meta: {
      layout: 'simple-layout'
    }
  }
];
