<template>
  <v-app>
    <v-content>
      <v-alert 
        :outline="alert.outline" 
        :type="alert.type" 
        :icon="alert.icon" 
        :color="alert.color" 
        :dismissible="alert.dismissible" 
        :transition="alert.transition" 
        :value="alert.val" v-model="alert.val"
      >
        {{alert.text}}</v-alert>
      <v-snackbar
        :color="snackbar.color"
        :timeout="snackbar.timeout"
        v-model="snackbar.visible"
        :top="snackbar.top"
        :left="snackbar.left"
        :right="snackbar.right"
        :bottom="snackbar.bottom"
      >
        {{ snackbar.text }}
      <v-btn v-if="snackbar.close" dark flat @click="closeSnackbar">Close</v-btn>
      </v-snackbar>
      <v-dialog v-model="loading" persistent max-width="150" content-class="loadingDialog">
        <v-progress-circular indeterminate :size="100" :width="3" color="primary" class="mx-auto"></v-progress-circular>
      </v-dialog>
      <v-slide-y-transition mode="out-in">
          <router-view></router-view>
      </v-slide-y-transition>
    </v-content>
  </v-app>
</template>

<script>
  import { mapGetters } from 'vuex'

  export default {
    data () {
      return {
        clipped: true,
        drawer: false,
        fixed: false,
        validUser: true,
        user: {
          avatar: "https://randomuser.me/api/portraits/men/85.jpg"
        },
        miniVariant: true,
        right: true,
        rightDrawer: false,
        title: 'Talentera'
      }
    },
    computed: {
      ...mapGetters([
        'alert',
        'snackbar',
        'loading',
        'layout'
      ])
    },
    methods: {
      closeSnackbar() {
        this.$store.dispatch('closeSnackbar');
      },
    },
    async created(){}
  }
</script>

<style>
.v-input__slot {
  margin-bottom: 0 !important;
}
</style>
