<template>
  <div id="wrap">
    <Aside></Aside>
    <Header></Header>
    <Main></Main>
    <Footer></Footer>
  </div>
  <!--
    <v-app>
    <v-navigation-drawer
      persistent
      width="230"
      :clipped="$vuetify.breakpoint.lgAndUp"
      v-model="drawer"
      enable-resize-watcher
      app
      class="sideBar"
    >
      <v-icon class="closeIcon">close</v-icon>
      <v-toolbar flat>
        <v-menu offset-y class="nav_Wrap">
          <v-btn slot="activator" color="primary" dark class="navButton">보고서 목록보기</v-btn>
          <v-list>
            <v-list-tile
              v-for="(item, i) in items1"
              :key="i"
              :to="{path: `/${item.link}`}"
              :exact="i === 0"
            >
              <v-list-tile-title>{{ item.title }}</v-list-tile-title>
            </v-list-tile>
          </v-list>
        </v-menu>
      </v-toolbar>
      <v-toolbar flat>
        <v-menu offset-y class="nav_Wrap">
          <v-btn
            slot="activator"
            color="primary"
            dark
            class="navButton"
            v-for="(item, i) in items2"
            :key="i"
            :to="{path: `/${item.link}`}"
            :exact="i === 0"
          >보고서 뷰어</v-btn>
        </v-menu>
      </v-toolbar>
      <v-toolbar flat>
        <v-menu offset-y class="nav_Wrap">
          <v-btn slot="activator" color="primary" dark class="navButton">레이아웃</v-btn>
          <v-list>
            <v-list-tile
              v-for="(item, i) in items3"
              :key="i"
              :to="{path: `/${item.link}`}"
              :exact="i === 0"
            >
              <v-list-tile-title>{{ item.title }}</v-list-tile-title>
            </v-list-tile>
          </v-list>
        </v-menu>
      </v-toolbar>
      <v-toolbar flat>
        <v-menu offset-y class="nav_Wrap">
          <v-btn
            slot="activator"
            color="primary"
            dark
            class="navButton"
            v-for="(item, i) in items4"
            :key="i"
            :to="{path: `/${item.link}`}"
            :exact="i === 0"
          >서버 목록보기</v-btn>
        </v-menu>
      </v-toolbar>
    </v-navigation-drawer>
    <v-toolbar fixed app dark :clipped-left="clipped" v-show="validUser" color="primary">
      <v-toolbar-title class="d-flex align-center ml-0 mr-2">
        <div class="hamburgerMenu" @click.exact="showTopMenu = !showTopMenu" @click.stop="drawer = !drawer">
          <div v-if="!showTopMenu" class="xMenu">
            X
          </div>
          <div v-else>
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
        <router-link class="logo" :to="logo.link">
          <img src="../assets/AdminLogo.png" title="Logo">
        </router-link>
      </v-toolbar-title>
      <v-text-field
        flat
        solo-inverted
        prepend-icon="search"
        label="Search"
        class="hidden-sm-and-down ml-5"
      ></v-text-field>
      <v-spacer></v-spacer>
      <v-menu offset-y transition="slide-y-transition" bottom v-if="!$route.meta.candidateView">
        <v-list-tile-avatar slot="activator">
          <img v-bind:src="user.avatar">
        </v-list-tile-avatar>
        <v-list>
          <v-list-tile>
            <v-list-tile-action>
              <v-icon>sentiment_satisfied_alt</v-icon>
            </v-list-tile-action>
            <v-list-tile-title>오스템 님</v-list-tile-title>
          </v-list-tile>
          <v-list-tile active-class :to="{path: '/my-account'}">
            <v-list-tile-action>
              <v-icon>account_box</v-icon>
            </v-list-tile-action>
            <v-list-tile-title>프로필보기</v-list-tile-title>
          </v-list-tile>
          <v-list-tile>
            <v-list-tile-action>
              <v-icon>lock</v-icon>
            </v-list-tile-action>
            <v-list-tile-title>Role 확인</v-list-tile-title>
          </v-list-tile>
          <v-list-tile @click="logout">
            <v-list-tile-action>
              <v-icon>exit_to_app</v-icon>
            </v-list-tile-action>
            <v-list-tile-title>로그아웃</v-list-tile-title>
          </v-list-tile>
        </v-list>
      </v-menu>
    </v-toolbar>
    <v-content>
      공지사항 바
      <v-alert
        :outline="alert.outline"
        :type="alert.type"
        :icon="alert.icon"
        :color="alert.color"
        :dismissible="alert.dismissible"
        :transition="alert.transition"
        :value="alert.val"
        v-model="alert.val"
        class="noticeBar"
      >
        <span class="notice">{{alert.text}}</span>
        <v-badge color="red" class="bell">
          <span slot="badge">5</span>
          <v-icon medium color="grey">notifications</v-icon>
        </v-badge>
      </v-alert>
       보고서 목록 아이콘 
      <div class="reportIcon_Wrap">
        <div class="reportIcon">
          <img src="../assets/table.png" title="table">
        </div>
        <div class="reportIcon">
          <img src="../assets/card.png" title="card">
        </div>
      </div>
      <v-snackbar
        :color="snackbar.color"
        :timeout="snackbar.timeout"
        v-model="snackbar.visible"
        :top="snackbar.top"
        :left="snackbar.left"
        :right="snackbar.right"
        :bottom="snackbar.bottom"
      >
        {{ snackbar.text }}
        <v-btn v-if="snackbar.close" dark flat @click="closeSnackbar">Close</v-btn>
      </v-snackbar>
      <v-dialog v-model="loading" persistent max-width="150" content-class="loadingDialog">
        <v-progress-circular indeterminate :size="100" :width="3" color="primary" class="mx-auto"></v-progress-circular>
      </v-dialog>
      <v-slide-y-transition mode="out-in">
        <router-view></router-view>
      </v-slide-y-transition>
    </v-content>
    <v-footer :fixed="fixed" app v-show="validUser">
      <span>&nbsp; &copy; osstem Implant</span>
    </v-footer>
  </v-app>
  -->
</template>

<script>
import Aside from "../components/Aside.vue";
import Header from "../components/Header.vue";
import Main from "../components/Main.vue";
import Footer from "../components/Footer.vue";
import reset from "../stylus/reset.styl";
import { mapGetters } from "vuex";
import tokenManager from "@/util/token-manager.js";

export default {
  components: {
    Aside,
    Header,
    Main,
    Footer
  },
  data() {
    return {
      logo: {
        link: '/'+this.$store.getters.firstPagePath,
      },
      items1: [
        {
          title: "보고서",
          link: "report-list"
        }
      ],
      items2: [
        {
          title: "서브",
          link: "server-list"
        }
      ],
      items3: [
        {
          title: "환경설정",
          link: "charts"
        }
      ],
      items4: [
        {
          title: "공지사항",
          link: "listing-table"
        }
      ],
      right: null,

      clipped: true,
      drawer: true,
      fixed: false,
      validUser: true,
      user: {
        avatar: "https://randomuser.me/api/portraits/men/85.jpg"
      },
      navs: [],
      miniVariant: true,
      right: true,
      rightDrawer: false,
      title: "Talentera",
      showTopMenu: false
    };
  },
  computed: {
    orderedNavs: function() {
      return this.navs.sortBy("order");
    },
    ...mapGetters(["alert", "snackbar", "loading"])
  },
  methods: {
    closeSnackbar() {
      this.$store.dispatch("closeSnackbar");
    },
    // 로그아웃
    logout() {
      // 토큰을 브라우저에서 제거한다.
      tokenManager.clearToken();
      // 로그인페이지를 이동하며, 저장되어있던 변수를 모두 제거한다.
      location.replace("/");
    },
    // 공지사항을 띄우는 메서드
    showNotice() {
      this.$store.dispatch("alert", {
        color: "#ddd",
        text: "공지사항입니다."
      });
    }
  },
  mounted() {
    // 공지사항을 띄웁니다.
    this.showNotice();
  }
};

Array.prototype.sortBy = function(p) {
  return this.slice(0).sort(function(a, b) {
    return a[p] > b[p] ? 1 : a[p] < b[p] ? -1 : 0;
  });
};
</script>

<style>
@charset "utf-8";

/* #wrap */
#wrap {
	position: relative;
	width: 100%;
	min-width: 1160px;
	min-height: 100%;
	height: auto;
}

/*
.sideBar {
  background-color: #f5f5f5 !important;
  padding-top: 30px;
}

.sideBar > nav {
  margin: 10px 0;
}

.closeIcon {
  margin-left: 80%;
}

.nav_Wrap {
  width: 100%;
}

.navButton {
  width: 100%;
}

.hamburgerMenu {
  width: 50px;
  height: auto;
  cursor: pointer;
}

.hamburgerMenu span {
  display: inline-block;
  width: 28px;
  height: 3px;
  background: #fff;
  float: left;
}

.hamburgerMenu span:nth-of-type(1) {
  margin-bottom: 5px;
}

.hamburgerMenu span:nth-of-type(2) {
  margin-bottom: 5px;
}

.xMenu {
  font-size: 1.5em;
}

.userSide {
  margin-right: 30px;
}

.noticeBar {
  margin-top: 1px;
}

.noticeBar > div {
  position: relative;
}

.bell {
  position: absolute;
  right: 3px;
}

.notice {
  line-height: 30px;
  color: #000;
}

.reportIcon_Wrap {
  width: 100%;
  padding: 15px 0 15px 88%;
}

.reportIcon {
  width: 40px;
  display: inline-block;
  margin-right: 10px;
  cursor: pointer;
}

.reportIcon img {
  width: 100%;
} 
*/
</style>
