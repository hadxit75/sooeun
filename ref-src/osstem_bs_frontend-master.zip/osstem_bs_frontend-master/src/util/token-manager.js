import jwtDecode from 'jwt-decode';
import store from '../store/index.js';
import cookieManager from './cookie-manager.js';
import {RefreshApi} from '@/api/backend';

/**
 * 토큰과 토큰의 세부정보를 Vuex에 저장합니다.
 * @param {string} accessToken 액세스용 토큰입니다.
 * @param {string} refreshToken 갱신용 토큰입니다.
 * @param {object} decodedAccessToken 디코딩되어 있는 액세스용 토큰입니다. 
 */
const saveTokenVuex = (accessToken, refreshToken, decodedAccessToken) => {
  // 토큰 및 토큰 세부정보를 vuex에 저장
  store.commit('ACCESS_TOKEN', accessToken);
  store.commit('REFRESH_TOKEN', refreshToken);
  store.commit('ACCESS_TOKEN_DATA', decodedAccessToken);
};

export default {
  /**
   * 토큰을 디코딩 후 로컬 저장소(Vuex, Cookie)에 저장합니다.
   * @param {string} accessToken 엑세스용 토큰입니다.
   * @param {string} refreshToken 갱신용 토큰입니다.
   */
  saveToken: (accessToken, refreshToken) => {
    // 토큰 세부 정보 확인
    const decodeAccessToken = jwtDecode(accessToken);
    const decodeRefreshToken = jwtDecode(refreshToken);
    // 토큰을 Vuex에 저장
    saveTokenVuex(accessToken, refreshToken, decodeAccessToken);

    // 토큰을 쿠키에 저장
    // (javascript의 Date객체는 밀리초까지 구분해서 1000을 곱함)
    // 액세스 토큰 저장
    cookieManager.setCookie('AccessToken',
      accessToken, decodeAccessToken.exp * 1000);
    // 리프레시 토큰 저장
    cookieManager.setCookie('RefreshToken',
      refreshToken, decodeRefreshToken.exp * 1000);
  },
  /**
   * 토큰을 쿠키로부터 가져온 뒤, 디코딩 과정을 거쳐
   * Vuex에 저장합니다.
   * @return {number} 쿠키에 AccessToken과 Refresh토큰이 모두 있을경우 2를,
   * RefreshToken만 있을경우 1를, 어떤 토큰도 없을경우 0을 리턴합니다.
   */
  loadTokenFromCookie: () => {
    // 토큰을 쿠키로부터 불러옵니다.
    const accessToken = cookieManager.getCookie('AccessToken');
    const refreshToken = cookieManager.getCookie('RefreshToken');
    // 쿠키에 데이터가 있었는지 확인
    let returnCode = 0;
    if (accessToken != null) {
      returnCode++;
    }
    if (refreshToken != null) {
      returnCode++
    }

    if (returnCode == 2) {
      //쿠키에 데이터가 있으면
      const decodeAccessToken = jwtDecode(accessToken);
      // 쿠키에서 불러온 토큰 및 토큰 세부정보를 vuex에 저장
      saveTokenVuex(accessToken, refreshToken, decodeAccessToken);
    }

    return returnCode;
  },
  /**
   * 만료된 AccessToken을 RefreshToken을 이용해 재 발급하며,
   * 이를 자동으로 로컬 저장소(Vuex, Cookie)에 저장합니다.
   * @return {Promise} 갱신의 성공, 실패 여부를 반환합니다.
   */
  refreshToken: () => {
    const refreshAction = async(resolve, reject) => {
      // Vuex에서 RefreshToken을 가져옵니다.
      let refreshToken = store.getters.refreshToken();

      //Backend에 토큰을 요청합니다.
      try {
        const newAccessToken = (await RefreshApi().get(info.apiList.refreshToken)).data;
        // 성공시 토큰을 저장하고 성공을 알립니다.
        saveToken(newAccessToken, refreshToken);
        resolve(data);
      } catch (err) {
        reject(new Error(err.response.data.message));
      };
    }
    new Promise(refreshAction);
  },
  /**
   * 토큰을 로컬 저장소(Cookie, Vuex)에서 제거합니다.
   * 수동 로그아웃에 사용됩니다.
   */
  clearToken: () => {
    // Vuex에서 토큰들을 삭제합니다.
    store.commit('ACCESS_TOKEN', '');
    store.commit('REFRESH_TOKEN', '');
    store.commit('ACCESS_TOKEN_DATA', {});
    // Cookie에서 토큰들을 삭제합니다.
    cookieManager.deleteCookie('AccessToken');
    cookieManager.deleteCookie('RefreshToken');
  },
};
