export default {
  env: process.env.NODE_ENV,
  api: {
    baseUrl: ''
  }
}