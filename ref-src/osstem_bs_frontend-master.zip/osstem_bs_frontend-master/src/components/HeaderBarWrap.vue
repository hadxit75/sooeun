<template>
    <div class="headerBar">
      <div class="headerBarWrap">
                  <ul class="pageRoute">
                      <li class="homeIcon"><img src="../assets/homeIcon.gif" alt="home_Icon" /></li>
                      <li><a href="#">업무현황시스템</a></li>
                      <li class="less"><a href="#"> > </a></li>
                      <li><a href="#">환경설정</a></li>
                      <li class="less"><a href="#"> > </a></li>
                      <li><a href="#">탭 설정하기</a></li>
                  </ul>
              <div class="headerSearch">
                  <input type="search" placeholder="검색어를 입력하세요." />
                  <div class="searchIcon">
                  <img src="../assets/searchIcon.gif" alt="검색버튼">
              </div>
          </div>
              </div>
                 <button class="iconMenu">
                     <div class="iconMenuWrap">
                        <span></span>
                        <span></span>
                        <span></span>
                     </div>
                </button>
      </div>
</template>

<script>
    export default {
	}
</script>

<style scoped>
/* .headerBar */
header .headerBar {
	width: 100%;
	height: 50px;
	background: #ff6600;
  position: relative;
  z-index: 5;
}

header .headerBar .headerBarWrap {
	width: 1160px;
	height: 100%;
	margin: 0 auto;
	position: relative;
}

header .headerBar .headerBarWrap .pageRoute {
	height: 100%;
	margin: 0 auto;
	display: inline-block;
	padding-top: 15px;
	position: absolute;
	left: 0;
}

header .headerBar .headerBarWrap .pageRoute li {
	display: inline;
	float: left;
}

header .headerBar .headerBarWrap .pageRoute li a {
	color: #fff;
}

header .headerBar .headerBarWrap .pageRoute .homeIcon {
	margin-right: 8px;
}

header .headerBar .headerBarWrap .pageRoute .less {
	padding: 0 15px;
}

header .headerBar .headerSearch {
	width: 330px;
	height: 100%;
	position: absolute;
	right: 0;
}

header .headerBar .headerSearch input {
	width: 290px;
	height: 34px;
	background: #ffdec9;
	border: none;
	display: inline-block;
	padding: 11px 15px;
	color: #6b6968;
	font-size: 10pt;
	font-family: 'Nanum Gothic', sans-serif;
	position: absolute;
	top: 8px;
	left: 0;
    -webkit-appearance: none; /* safari search */
}

header .headerBar .headerSearch .searchIcon {
	display: inline-block;
	position: absolute;
	top: 8px;
	right: 0;
	cursor: pointer;
}

header .headerBar .iconMenu {
	width: 80px;
	height: 50px;
	position: absolute;
	top: 0;
	right: 0;
}

header .headerBar .iconMenu .iconMenuWrap {
	position: absolute;
	top: 18px;
	left: 32px;
}

header .headerBar .iconMenu .iconMenuWrap span {
	display: block;
	width: 18px;
	height: 2px;
	margin-bottom: 3px;
	background: #fff;
}

header .headerBar .iconMenu .iconMenuWrap span:last-of-type {
	margin-bottom: 0;
}

button:focus { 
	outline:none 
}
</style>