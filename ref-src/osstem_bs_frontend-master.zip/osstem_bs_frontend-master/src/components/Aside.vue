<template>
    <aside>
      <div id="asideWrap">
        <ul class="iconMenuBtn">
          <li
            v-for="item in items1" :key="item.title">
              <router-link :to="{path: `/${item.link}`}"><img src="../assets/reportIcon.gif" alt="보고서"><span>{{ item.title }}</span></router-link>
          </li>
          <li
            v-for="item in items2" :key="item.title">
              <router-link :to="{path: `/${item.link}`}"><img src="../assets/serverIcon.gif" alt="서브"><span>{{ item.title }}</span></router-link></li>
          <li
            v-for="item in items3" :key="item.title">
              <router-link :to="{path: `/${item.link}`}"><img src="../assets/settingIcon.gif" alt="환경설정"><span>{{ item.title }}</span></router-link></li>
          <li
            v-for="item in items4" :key="item.title">
              <router-link :to="{path: `/${item.link}`}"><img src="../assets/noticeIcon.gif" alt="공지사항"><span>공지사항</span></router-link></li>
        </ul>
      </div>
    </aside>
</template>

<script>
import { mapGetters } from "vuex";
import tokenManager from "@/util/token-manager.js";

    export default {
        data() {
            return {
                logo: {
                    link: '/'+this.$store.getters.firstPagePath,
                },
                items1: [
                    {
                    title: "보고서",
                    link: "report-list"
                    }
                ],
                items2: [
                    {
                    title: "서브",
                    link: "server-list"
                    }
                ],
                items3: [
                    {
                    title: "환경설정",
                    link: "charts"
                    }
                ],
                items4: [
                    {
                    title: "공지사항",
                    link: "listing-table"
                    }
                ],
                right: null
            };
        }
    }
</script>

<style>
/* aside */
aside {
	position: absolute;
	right: 0;
	width: 80px;
	height: 100%;
    background: #5e5b59;
    z-index: 3;
}

aside #asideWrap {
	position: relative;
	height: 100%;
}

aside #asideWrap .iconMenuBtn {
	width: 100%;
	position: absolute;
	top: 128px;
}

aside #asideWrap .iconMenuBtn li {
	width: 100%;
	height: 100px;
}

aside #asideWrap .iconMenuBtn li:hover {
    background: #3E3F3F;
}

aside #asideWrap .iconMenuBtn li a {
	display: block;
	width: 100%;
}

aside #asideWrap .iconMenuBtn li a img {
	display: block;
	margin: 0 auto;
	padding-top: 28px;
}

aside #asideWrap .iconMenuBtn li a span {
	width: 100%;
	text-align: center;
	display: inline-block;
	margin-top: 8px;
	text-align: center;
	color: #fff;
}

aside.on {
    display: block;
}

aside.off {
    display: none;
}
</style>