<template>
  <div class="LoginError">
		<span>{{errorMsg}}</span>
	</div>
</template>
<script>
export default {
  props:{
    errorMsg: String,
  },
};
</script>

<style>
#login_Form .LoginError{
	width: 70%;
  float: left;
  margin: 10px 0;
}

#login_Form .LoginError span{
	display: block;
  padding: 5px;
  color: #555;
}

/* Media Query */
@media screen and (max-width: 767px) {
  #login_Form .LoginError span{
	  font-size: 0.35em;
    line-height: 35px;
  }

  #login_Form .LoginError{
    height: 35px;
  }
}

@media screen and (min-width: 768px) and (max-width: 959px) {
  #login_Form .LoginError span{
	  font-size: 0.4em;
    line-height: 40px;
  }

  #login_Form .LoginError{
    height: 40px;
  }
}

@media screen and (min-width: 960px) and (max-width: 1023px) {
  #login_Form .LoginError span{
	  font-size: 0.5em;
    line-height: 45px;
  }

  #login_Form .LoginError{
    height: 45px;
  }
}

@media screen and (min-width: 1024px) {
  #login_Form .LoginError span{ 
	  font-size: 0.6em;
    line-height: 50px;
  }

  #login_Form .LoginError{
    height: 50px;
  }
}
</style>