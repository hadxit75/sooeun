<template>
  <div class="loginForm">
    <div class="logoHeader">
      <div class="logoImage">
        <img src="../../assets/loginLogo.gif" alt="loginLogo">
      </div>
      <div class="loginSubTitle">
        <p>오스템 임플란트 업무현황시스템</p>
      </div>
    </div>
    <div class="inputForm">
      <div class="inputBox">
        <div class="inputWrap">
          <input type="text" id="id" placeholder="아이디" autocomplete="off" v-model="id" />
          <input type="password" id = "pwd" placeholder="비밀번호" autocomplete="off" v-model="password" />
          <input type="checkbox" checked />Remember Me
        </div>
        <button class="loginBtn" v-on:click="clickLoginBtn">로그인</button>
        <br>
        <error-message :errorMsg="errorMessage"></error-message>
      </div>
    </div>
  </div>
</template>

<script>
import tokenManager from "@/util/token-manager.js";
import ErrorMessage from "./ErrorMessage.vue";
import {LoginApi, info} from '@/api/backend.js';

export default {
  components: {
    ErrorMessage
  },
  //DATA
  data() {
    return {
      id: "",
      password: "",
      errorMessage: ""
    };
  },
  props:{
    	firstPage: String,
  },
  //METHODS
  methods: {
    // 버튼 클릭 이벤트 발생시
    clickLoginBtn: async function() {
      // 서버에 전송할 데이터 설정
      let json =
        '{"username":"' + this.id + '", "password":"' + this.password + '"}';
      // axios를 통해 서버와 통신
      try{
        const loginResult = (await LoginApi().post(info.apiList.login, json)).data;
        //로그인 성공시
        tokenManager.saveToken(loginResult.token, loginResult.refreshToken);
          // 메인 페이지로 이동
          // 메인 페이지는 Vuex 에서 수정 가능하므로 여기서 건들지 말 것
          this.$router.push({ name: this.$store.getters.firstPage });
      } catch (err){
        this.errorMessage = err.response.data.message;
      }
    }
  }
};
</script>


<style>
#content_wrap .loginForm {
	position: absolute;
	top: 50%;
	left: 50%;
	margin-top: 160px;
	margin-left: -400px;
	width: 800px;
	height: 365px;
	border: 1px solid #afafaf;
	box-sizing: border-box;
	z-index: 9;
}

#content_wrap .loginForm .logoHeader {
	width: 100%;
	height: 178px;
	background: #f1f1f1;
	position: relative;
}

#content_wrap .loginForm .logoHeader .logoImage {
	width: 100%;
	/*height: 90px;*/
	padding-top: 23px;
}

#content_wrap .loginForm .logoImage img {
	display: block;
	width: 253px;
	height: 100%;
	margin: 0 auto;
}

#content_wrap .loginForm .logoHeader .loginSubTitle {
	width: 100%;
	height: 65px;
}

#content_wrap .loginForm .logoHeader .loginSubTitle p {
	width: 100%;
	text-align: center;
	line-height: 65px;
	font-family: NanumSquareWeb, sans-serif;
	font-style: oblique;
	font-weight: bold;
	font-size: 14pt;
}

.loginForm_wrap .inputForm {
	width: 100%;
	height: 185px;
	background: #f1f1f1;
	position: relative;
}

.loginForm_wrap .inputForm .inputBox {
	width: 638px;
	height: 149px;
	background: #ebebeb;
	margin: 0 auto;
	position: relative;
}

.loginForm_wrap .inputForm .inputBox .inputWrap {
	width: 260px;
	position: absolute;
	left: 110px;
	top: 18px;
}

.loginForm_wrap .inputForm .inputBox .inputWrap #id,
.loginForm_wrap .inputForm .inputBox .inputWrap #pwd {
	width: 246px;
	height: 36px;
	padding-left: 14px;
	margin-bottom: 4px;
	border: 1px solid #d0d0d0;
}

.loginForm_wrap .inputForm .inputBox .inputWrap #pwd {
	margin-bottom: 12px;
}

.loginForm_wrap .inputForm .inputBox button {
	width: 142px;
	height: 78px;
	background: #ff6600;
	color: #fff;
	font-size: 12pt;
	font-weight: bold;
	border-radius: 5px;
	position: absolute;
	top: 18px;
	right: 108px;
}
</style>
