<template>
<div id="wrap">
		<content id="content_wrap">
			<div class="loginForm_wrap">
				<login-form></login-form>
			</div>
		</content>
		<footer id="loginFooter">
			<div class="footer_wrap">
				<!--<p>오스템 임플란트 업무현황시스템은 허가된 사용자만 접속이 가능합니다.</p>-->
			</div>
		</footer>
	</div>
</template>

<script>
import reset from "../../stylus/reset.styl";
import LoginForm from "./LoginForm.vue";

export default {
    components : {
        LoginForm
		},
		props:{
    	firstPage: String,
  },
}
</script>

<style>
#wrap {
	position: relative;
	width: 100%;
	min-height: 100%;
	height: auto;
}

#content_wrap {
	width: 100%;
	height: 100%;
	position: relative;
}

#content_wrap .loginForm_wrap {
	position: relative;
}

#loginFooter {
	position: absolute;
	width: 400px;
	height: 100%;
	top: 0;
	background: #ff6600;
}
</style>
