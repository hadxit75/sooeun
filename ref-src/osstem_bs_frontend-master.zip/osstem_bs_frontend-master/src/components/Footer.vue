<template>
    <footer>
      <div id="footerWrap">
        <div class="block">
        		<ul class="footerLink">
        			<li><a href="#">개인정보처리방침</a></li>
        			<span> | </span>
        			<li><a href="#">이메일무단수집거부</a></li>
        		</ul>
        </div>
        <div class="block">
        	서울시 금천구 가산디지털2로 123 월드메르디앙 2차 8층
        	<span>&nbsp;</span>
        	사업자등록번호 : 112-81-47103
        	<span>&nbsp;</span>
        	의료기기판매업신고번호 : 제 183호
        	<span>&nbsp;</span>
        	프로그램 고객센터 : 1588-7522
        	<span>&nbsp;</span>
        	FAX : 02-2016-7001
        	<span>&nbsp;</span>
        </div>
        <p class="copyright">
        	Copyright(c)
        	<strong>OSSTEM</strong>
        	IMPLANT CO., LTD.ALL RIGHT RESERVED
        </p>
      </div>	
    </footer>
</template>

<script>
export default {
    
}
</script>

<style>
/* footer */
footer {
    clear: both;
    width: 100%;
	  position: absolute;
	  bottom: 0;
    border-top: 1px solid #c8c8c8;
    font-size: 10pt;
}

footer #footerWrap {
    position: relative;
    max-width: 1160px;
    margin: 0 auto;
    color: #8e8e8e;
    line-height: 18px;
    padding: 10px 0;
}

footer #footerWrap .block {
    position: relative;
    margin: 5px 10px 5px 0;
}

footer #footerWrap .block ul.footerLink li {
    display: inline-block;
}

footer #footerWrap .block ul.footerLink li a {
    color: #8e8e8e;
}

.copyright {
    clear: both;
    font-size: 9pt;
}
</style>
