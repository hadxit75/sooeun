<template>
    <div class="pagination">
        <a href="#">&laquo;</a>
		<a href="#">1</a>
		<a class="active" href="#">2</a>
		<a href="#">3</a>
		<a href="#">4</a>
		<a href="#">5</a>
		<a href="#">6</a>
		<a href="#">&raquo;</a>
	</div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
main #listContainer .pagination {
    width: 100%;
    position: relative;
    clear: both;
    display: block;
    text-align: center;
    margin-top: 25px;
}

main #listContainer .pagination  a {
    display: inline-block;
    width: 30px;
    height: 30px;
    border: 1px solid #ddd;
    text-align: center;
    line-height: 30px;
    color: #000;
}
</style>