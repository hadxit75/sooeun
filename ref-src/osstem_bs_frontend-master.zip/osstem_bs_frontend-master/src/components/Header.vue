<template>
    <header>
    <div class="gnb">
      <div class="gnbWrap">
        <div class="logo">
          <img src="../assets/logo.gif" alt="osstem logo">
        </div>
        <div class="gnb_my">
          <ul>
            <li>
              <span class="my_profile"></span>
              <a href="#"><span class="orangeName">오스템</span>님</a>
              <span class="bar"> | </span>
            </li>
            <li>
              <a href="#">프로필 보기</a>
              <span class="bar"> | </span>
            </li>
            <li>
              <a href="#">Role 확인</a>
              <span class="bar"> | </span>
            </li>
            <li @click="logout"><a href="#">로그아웃</a></li>
          </ul>
        </div>
      </div>
    </div>
    <HeaderBarWrap></HeaderBarWrap>
  </header>
</template>

<script>
import HeaderBarWrap from "./HeaderBarWrap.vue";

export default {
	components: {
		HeaderBarWrap
  },
   methods: {
    // 로그아웃
    logout() {
      // 토큰을 브라우저에서 제거한다.
      tokenManager.clearToken();
      // 로그인페이지를 이동하며, 저장되어있던 변수를 모두 제거한다.
      location.replace("/");
    }
  }
}
</script>


<style>
/* header */
header {
	width: 100%;
	height: 168px;
}

/* .gnb */
header .gnb {
	width: 100%;
	height: 78px;
	position: relative;
	/*clear: both;*/
}

header .gnb .gnbWrap {
	width: 1160px;
	height: 100%;
	margin: 0 auto;
	padding: 22px 3px;
	position: relative;
}

header .gnb .gnbWrap .logo {
	float: left;
}

header .gnb .gnbWrap .gnb_my {
	font-size: 14pt;
	font-family: 'Nanum Square', sans-serif;
	padding-top: 4px;
	position: absolute;
	top: 26px;
	right: 20px;
}

header .gnb .gnbWrap .gnb_my ul li a{
	color: #666;
}

header .gnb .gnbWrap .gnb_my ul li{
	display: inline;
	float: left;
}

header .gnb .gnbWrap .gnb_my .orangeName {
	color: #cc6633;
}

header .gnb .gnbWrap .gnb_my ul li .bar {
	padding: 0 11px;
}
</style>
