<template>
    <main>
      <div id="listContainer">
				<router-view></router-view>
        <Pagination></Pagination>
      </div>
    </main>
</template>

<script>
import Table from "./Table.vue";
import Pagination from "./Pagination.vue";

    export default {
        components: {
					Table,
					Pagination
		}
    }
</script>

<style scoped>
/* main */
main {
	clear: both;
	margin-top: 40px;
	position: relative;
	width: 1160px;
	margin: 0 auto;
  padding: 0 0 150px 0;
}

main #listContainer {
	width: auto;
	height: auto;
	position: relative;
}
</style>