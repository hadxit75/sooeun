<template>
    <table>
        <thead>
        	<tr>
				<th class="td1">선택</th>
				<th class="td2">번호</th>
				<th class="td3">제목</th>
				<th class="td4">작성자</th>
        	</tr>
        </thead>
    	<tbody>
        	<tr>
				<td class="td1">별아이콘</td>
				<th class="td2">1</th>
				<td class="td3">이곳에 오스템 임플란트 업무현황시스템 보고서 타이틀이 들어갑니다.</td>
				<td class="td4">이수연</td>
			</tr>
			<tr>
				<td class="td1">별아이콘</td>
				<th class="td2">2</th>
				<td class="td3">이곳에 오스템 임플란트 업무현황시스템 보고서 타이틀이 들어갑니다.</td>
				<td class="td4">이수연</td>
			</tr>
			<tr>
				<td class="td1">별아이콘</td>
				<th class="td2">3</th>
				<td class="td3">이곳에 오스템 임플란트 업무현황시스템 보고서 타이틀이 들어갑니다.</td>
				<td class="td4">이수연</td>
			</tr>
        </tbody>
    </table>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
main #listContainer table {
	margin-top: 24px;
	display: block;
	width: 100%;
}

main #listContainer table thead {
	border-top: 2px solid #797979;
	display: block;
	width: 100%;
	height: 40px;
}

main #listContainer table thead tr {
	background: #f8f8f8;
	display: block;
	width: 100%;
	height: 100%;
}

main #listContainer table thead tr th {
	display: inline-block;
	border-right: 1px solid #dadada;
	height: 100%;
	line-height: 40px;
	font-size: 11pt;
	font-weight: normal;
    border-bottom: 1px solid #dadada;
}

main #listContainer table thead tr td {
	display: inline-block;
	height: 100%;
	line-height: 40px;
	font-size: 11pt;
	font-weight: normal;
}

main #listContainer table tbody {
	display: block;
	width: 100%;
    text-align: center;
}

main #listContainer table tbody tr {
	background: #fff;
	display: block;
	width: 100%;
	height: 100%;
    border-bottom: 1px solid #dadada;
}

main #listContainer table tbody tr th {
	display: inline-block;
	height: 100%;
	line-height: 40px;
	font-size: 11pt;
	font-weight: normal;
    border-right: 1px solid #dadada;
}

main #listContainer table tbody tr td {
	display: inline-block;
	height: 100%;
	line-height: 40px;
	font-size: 11pt;
	font-weight: normal;
    border-right: 1px solid #dadada;
}

main #listContainer table thead tr .td1 {
	width: 112px;
}

main #listContainer table thead tr .td2 {
	width: 120px;
}

main #listContainer table thead tr .td3 {
	width: 726px;
}

main #listContainer table thead tr .td4 {
	width: 186px;
	border-right: none;
}

main #listContainer table tbody tr .td1 {
	width: 112px;
}

main #listContainer table tbody tr .td2 {
	width: 120px;
}

main #listContainer table tbody tr .td3 {
	width: 726px;
}

main #listContainer table tbody tr .td4 {
	width: 186px;
	border-right: none;
}
</style>