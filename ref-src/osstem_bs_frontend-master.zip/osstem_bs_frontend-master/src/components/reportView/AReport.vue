<template>
  <div>
    <iframe :src="reportInfo.reportUrl" class="areport"/>
  </div>
</template>

<script>
export default {
  props: {
    reportInfo: {
      type: Object,
      default: () => { 
        return {
          uri:'',
        };
      }
    },
  },
  methods: {
    log() {
      console.log(this.reportInfo);
    }
  },
};
</script>

<style>
</style>