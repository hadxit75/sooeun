const FIRST_PAGE = 'FIRST_PAGE'

const state = {
    firstPage: 'ReportList'
};

const getters = {
    // firstPage를 반환
    firstPage (state) {
        return state.firstPage;
    },
    // firstPage가 파스칼 표기법이므로 이를 변환하여 반환
    // router-link 등에 사용
    firstPagePath (state) {
        return state.firstPage.split(/(?=[A-Z])/).join('-').toLowerCase();
    }
};

const mutations = {
    [FIRST_PAGE] (state, payload) {
        state.firstPage = payload
    }
};


export default {
  state,
  getters,
  mutations
}