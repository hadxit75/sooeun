const REPORT_OBJECT = 'REPORT_OBJECT';

// State(상태)
// 이곳에서 상태를 저장한다.
const state = {
  reportObject: [],
};

// Getters
// 상태의 값을 확인한다. 연산작업이 있다면 이를 캐싱하여 효율적이다.
const getters = {
  reportObject(state) {
    return state.reportObject;
  },
};

// Mutations (변이)
// State를 동기적으로 변화시킨다. commit을 통해 접근한다.
const mutations = {
  [REPORT_OBJECT](state, payload) {
    state.reportObject = payload;
  },
};

export default {
  state,
  getters,
  mutations,
}
