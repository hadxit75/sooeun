import Vue from 'vue';
import Vuex from 'vuex';

import message from '@/store/modules/message.js';
import loading from '@/store/modules/loading.js';
import layout from '@/store/modules/layout.js';
import account from '@/store/modules/account.js';
import report from '@/store/modules/report.js';

// Vue.use(Vuex)를 호출합니다.
Vue.use(Vuex);

const store = new Vuex.Store({
  // plugins: [createPersistedState({
  // 	paths: ['lang']
  // })],
  modules: {
    message,
    // lang,
    loading,
    layout,
    account,
    report,
  }
});

export default store;
